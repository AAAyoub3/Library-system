package frontend;

public interface Node {
    public Node getParentNode();
    public void setParentNode(Node node);
   
}