package constants;

public interface FileNames {
    String BOOKS_FILENAME = "C:\\Users\\shaym\\OneDrive\\Desktop\\Books.txt\\";
    String LIBRARIANS_FILENAME = "C:\\Users\\shaym\\OneDrive\\Desktop\\Librarians.txt";
    String STUDENTSBOOKS_FILENAME = "C:\\Users\\shaym\\OneDrive\\Desktop\\StudentsBooks.txt";
}
