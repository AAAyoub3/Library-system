package constants;

public interface LoginCredentials {
    String ADMIN_USERNAME = "admin";
    String ADMIN_PASSWORD = "12345";
    String LIBRARIAN_USERNAME = "librarian";
    String LIBRARIAN_PASSWORD = "56789";
}
