package backend;
public interface allRecords {
    String lineRepresentation();
    String getSearchKey();
}
